<?php
session_start();

$host = "localhost";
$login = "root";
$pass = "";
$bdd = "supercar";

$conn = mysqli_connect($host, $login, $pass, $bdd);
if (!$conn) {
    die("Échec de la connexion : " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST["nom"] ?? null;
    $prenom = $_POST["prenom"] ?? null;
    $email= $_POST["email"] ?? null;
    $lieurecup = $_POST["lieurecup"] ?? null;
    $lieudepot = $_POST["lieudepot"] ?? null;
    $daterecup = $_POST["daterecup"] ?? null;
    $datedepot = $_POST["datedepot"] ?? null;
    $heurerecup = $_POST["heurerecup"] ?? null;

    if (!$nom || !$prenom || !$email) {
        die("Erreur : tous les champs requis ne sont pas remplis !");
    }

    // Insérer dans la base de données
    $demande = "INSERT INTO essai (nom, prenom, email, lieurecup, lieudepot, daterecup, datedepot, heurerecup) 
                 VALUES ('$nom', '$prenom', '$email', '$lieurecup', '$lieudepot', '$daterecup', '$datedepot', '$heurerecup')";

    if (mysqli_query($conn, $demande)) {
        $_SESSION['confirmation'] = "Votre demande a bien été prise en compte. Nous reviendrons vers vous pour votre essai.";
        ?>
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <title>Confirmation</title>
            <style>
                body, html {
                    margin: 0;
                    padding: 0;
                    height: 100%;
                    font-family: Arial, sans-serif;
                    color: white;
                    overflow: hidden;
                }

                .video-background {
                    position: fixed;
                    top: 0;
                    left: 0;
                    min-width: 100%;
                    min-height: 100%;
                    z-index: -1;
                    object-fit: cover;
                }

                .confirmation-container {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    height: 100vh;
                    text-align: center;
                    background-color: rgba(0, 0, 0, 0.5); /* assombrit légèrement pour la lisibilité */
                    padding: 20px;
                }

                .confirmation-title {
                    font-size: 40px;
                    font-weight: bold;
                    margin-bottom: 30px;
                    color: #00ff88;
                }

                .confirmation-message {
                    font-size: 24px;
                    margin-bottom: 40px;
                }

                .btn {
                    padding: 12px 24px;
                    font-size: 18px;
                    margin: 10px;
                    text-decoration: none;
                    color: white;
                    background-color: #007BFF;
                    border: none;
                    border-radius: 8px;
                    cursor: pointer;
                    transition: background-color 0.3s ease;
                }

                .btn:hover {
                    background-color: #0056b3;
                }
            </style>
        </head>
        <body>
            <!-- Vidéo de fond -->
            <video autoplay muted loop class="video-background">
                <source src="video/Demande reussi .mp4" type="video/mp4">
                Votre navigateur ne supporte pas la lecture de vidéo.
            </video>

            <div class="confirmation-container">
                <div class="confirmation-title">Demande enregistrée avec succès !</div>
                <div class="confirmation-message"><?php echo $_SESSION['confirmation']; ?></div>
                <a class="btn" href="Acceuil.php">Retour à l'accueil</a>
                <button class="btn" onclick="history.back()">Retour à la page précédente</button>
            </div>
        </body>
        </html>
        <?php
    } else {
        echo "Erreur SQL : " . mysqli_error($conn);
    }
} else {
    echo "Accès interdit.";
}
?>
