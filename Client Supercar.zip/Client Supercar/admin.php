<?php
 session_start(); 

$pdo = new PDO("mysql:host=localhost;dbname=supercar","root", "");

// Hacher le mot de passe
$password = password_hash("admin123", PASSWORD_DEFAULT);

$sql = "INSERT INTO admin (username, password) VALUES ('admin1','12345678')";
$stmt = $pdo->prepare($sql);
$stmt->execute([$password]);

echo "Admin ajouté avec succès !";
?>