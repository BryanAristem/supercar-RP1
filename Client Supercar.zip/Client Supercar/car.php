<?php
session_start();

// Handle logout action
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    setcookie('user_id', '', time() - 3600, '/');
    setcookie('user_nom', '', time() - 3600, '/');
    header("Location: Acceuil.php");
    exit();
}

if (!isset($_SESSION["user_id"]) && isset($_COOKIE["user_id"])) {
    $_SESSION["user_id"] = $_COOKIE["user_id"];
    $_SESSION["user_nom"] = $_COOKIE["user_nom"];
}

$host = 'localhost';
$db   = 'supercar';
$user = 'root';
$pass = '';

$dsn = "mysql:host=$host;dbname=$db";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

$stmt = $pdo->query('SELECT * FROM voiture');
$voitures = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Voitures</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container-fluid px-0">
        <a class="navbar-brand ml-lg-5 ml-3" href="index.html" style="margin-right: -50px;">Super<span>car</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
          <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav mx-auto" style="max-width: 600px; width: 100%; display: flex; flex-wrap: nowrap;">
            <li class="nav-item"><a href="Acceuil.php" class="nav-link">Accueil</a></li>
            <li class="nav-item active"><a href="car.php" class="nav-link">Voitures</a></li>
            <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
            <li class="nav-item" style="display: inline-flex;">
              <a href="demande.php" class="nav-link" style="white-space: nowrap;">Demande d'essai</a>
              <span style="color: rgba(255,255,255,0.5); margin: 0 5px;"></span>
              <a href="contacts.php" class="nav-link" style="white-space: nowrap;">Contactez-nous</a>
            </li>
          </ul>
          <div class="navbar-text user-info">
            <?php if (isset($_SESSION['user_id'])): ?>
              <i class="fas fa-user" style="font-size: 0.9rem;"></i>
              <?php $username = $_SESSION['user_nom'] ?? 'Utilisateur'; echo htmlspecialchars($username); ?>
              <a href="?action=logout" class="nav-link logout-btn"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
            <?php else: ?>
              <a href="connexion.php" class="nav-link">Se connecter</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </nav>

    <style>
      @media (min-width: 992px) {
        .navbar-nav .nav-item[style*="inline-flex"] { display: inline-flex !important; align-items: center; }
        .navbar-brand { position: relative; left: -30px; }
        #ftco-nav { width: calc(100% - 200px); }
      }
      @media (max-width: 991px) {
        .navbar-nav .nav-item[style*="inline-flex"] { display: block !important; }
        .navbar-nav .nav-item[style*="inline-flex"] span { display: none; }
      }
      img { width: 100%; height: 200px; object-fit: cover; }
      .car-wrap:hover { transform: scale(1.03); transition: transform 0.3s ease; }
    </style>

    <section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('images/VOITURE.webp');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
            <p class="breadcrumbs"><span class="mr-2"><a href="Acceuil.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>Voitures <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-3 bread">Catalogue de voitures</h1>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row">
<?php foreach($voitures as $index => $voiture): ?>
    <div class="col-md-4 car-item">
        <div class="car-wrap rounded ftco-animate">
            <div class="img rounded d-flex align-items-end" style="background-image: url(<?= htmlspecialchars($voiture['photo'] ?? 'images/default.jpg') ?>);"></div>
            <div class="text">
                <h2 class="mb-0"><a href="#"><?= htmlspecialchars($voiture['marque'] . ' ' . $voiture['modele']) ?></a></h2>
                <div class="d-flex mb-3">
                    <span class="cat"><?= htmlspecialchars($voiture['categorie'] ?? 'Non spécifiée') ?></span>
                    <p class="price ml-auto"><?= number_format($voiture['prix'], 2) ?><span>MUR /jour</span></p>
                </div>
                <p class="description" style="display:none;"><?= htmlspecialchars($voiture['description'] ?? 'Aucune description') ?></p>
                <p class="transmission" style="display:none;"><?= htmlspecialchars($voiture['transmission'] ?? 'Non spécifiée') ?></p>
                <p class="d-flex mb-0 d-block">
                    <a href="demande.php?voiture_id=<?= htmlspecialchars($voiture['id']) ?>" class="btn btn-primary py-2 mr-1">Essayer</a>
                    <button class="btn btn-secondary py-2 ml-1" data-target="#carDetailsModal<?= $voiture['id'] ?>">Details</button>
                </p>
            </div>
        </div>
    </div>
    <?php if (($index + 1) % 3 == 0): ?>
        </div><div class="row">
    <?php endif; ?>
<?php endforeach; ?>
        </div>

        <div class="modal fade" id="carDetailsModal" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="modalCarTitle"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
              </div>
              <div class="modal-body text-center">
                <img id="modalCarPhoto" src="" class="img-fluid mb-3" alt="">
                <p><strong>Catégorie:</strong> <span id="modalCarCategorie"></span></p>
                <p><strong>Prix:</strong> <span id="modalCarPrix"></span> MUR / jour</p>
                <p><strong>Description:</strong> <span id="modalCarDescription"></span></p>
                <p><strong>Transmission:</strong> <span id="modalCarTransmission"></span></p>
              </div>
              <div class="modal-footer">
                <a href="demande.php" class="btn btn-primary">Tester cette voiture</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <footer style="background: linear-gradient(135deg, #021638cc, #12906c, #021638cc); color: white; padding: 1.5rem 0; text-align: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; position: relative; margin-top: 3rem; box-shadow: 0 -5px 15px rgba(0,0,0,0.1);">
      <div style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
        <p style="margin: 0; font-size: 1.1rem; letter-spacing: 1px; display: flex; justify-content: center; align-items: center; gap: 10px; flex-wrap: wrap;">
          <span style="font-weight: bold;">&copy; SUPERCAR 2024-2026</span>
          <span style="color: rgba(255,255,255,0.8);">|</span>
          <span>By Student MCCI</span>
          <span style="color: rgba(255,255,255,0.8);">|</span>
          <span>SIO</span>
        </p>
        <div style="margin-top: 1rem; display: flex; justify-content: center; gap: 1.5rem;">
          <a href="contacts.php" style="color: white; text-decoration: none; transition: all 0.3s;"><i class="fas fa-envelope"></i> Contact</a>
          <a href="confidentialité.html" style="color: white; text-decoration: none; transition: all 0.3s;"><i class="fas fa-shield-alt"></i> Confidentialité</a>
          <a href="Mention.html" style="color: white; text-decoration: none; transition: all 0.3s;"><i class="fas fa-file-alt"></i> Mentions légales</a>
        </div>
      </div>
    </footer>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/jquery.timepicker.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>

    <script>
      function filterCars(brand, btn) {
        const cars = document.querySelectorAll('.car-item');
        const buttons = document.querySelectorAll('.btn-group .btn');
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        cars.forEach(car => {
          if (car.classList.contains(brand)) {
            car.style.display = 'block';
          } else {
            car.style.display = 'none';
          }
        });
      }
      window.addEventListener('DOMContentLoaded', () => {
        filterCars('bmw', document.querySelector('.btn-group .btn.active'));
      });
    </script>

    <script>
      document.addEventListener('DOMContentLoaded', function() {
        const modal = new bootstrap.Modal(document.getElementById('carDetailsModal'));
        const buttons = document.querySelectorAll('button[data-target^="#carDetailsModal"]');
        buttons.forEach(button => {
          button.addEventListener('click', function() {
            const carId = this.getAttribute('data-target').replace('#carDetailsModal', '');
            const row = document.querySelector(`button[data-target="#carDetailsModal${carId}"]`).closest('.col-md-4');
            const marqueModele = row.querySelector('h2 a').textContent;
            const photo = row.querySelector('.img').style.backgroundImage.slice(5, -2);
            const categorie = row.querySelector('.cat').textContent;
            const prix = row.querySelector('.price').textContent.split(' ')[0];
            const description = row.querySelector('p.description') ? row.querySelector('p.description').textContent : 'Aucune description';
            const transmission = row.querySelector('p.transmission') ? row.querySelector('p.transmission').textContent : 'Non spécifiée';
            document.getElementById('modalCarTitle').textContent = marqueModele;
            document.getElementById('modalCarPhoto').src = photo;
            document.getElementById('modalCarPhoto').alt = marqueModele;
            document.getElementById('modalCarCategorie').textContent = categorie;
            document.getElementById('modalCarPrix').textContent = prix;
            document.getElementById('modalCarDescription').textContent = description;
            document.getElementById('modalCarTransmission').textContent = transmission;
            modal.show();
          });
        });
      });
    </script>
  </body>
</html>