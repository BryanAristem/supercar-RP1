<?php
session_start();

// Gestion de la déconnexion
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    setcookie('user_id', '', time() - 3600, '/');
    setcookie('user_nom', '', time() - 3600, '/');
    header("Location: Acceuil.php");
    exit();
}

// Récupérer la session depuis les cookies si elle n'existe pas
if (!isset($_SESSION["user_id"]) && isset($_COOKIE["user_id"])) {
    $_SESSION["user_id"] = $_COOKIE["user_id"];
    $_SESSION["user_nom"] = $_COOKIE["user_nom"] ?? 'Utilisateur';
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --light: #f8f9fa;
            --dark: #1a1a2e;
            --border-radius: 12px;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: url('images/supe.jpeg') center/100% no-repeat fixed;
            position: relative; 
        }

        /* Overlay semi-transparent */
        body::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4);
            z-index: 0;
        }

        .dashboard-card {
            background: rgba(255, 255, 255, 0.9);
            border-radius: var(--border-radius);
            padding: 30px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            text-align: center;
            position: relative;
            z-index: 1;
        }

        .welcome-message h1 {
            color: var(--primary);
            margin-bottom: 10px;
        }

        .action-btn {
            display: block;
            background: var(--primary);
            color: white;
            padding: 12px;
            border-radius: var(--border-radius);
            text-decoration: none;
            margin: 15px 0;
            transition: all 0.3s;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background: #3a56d4;
        }

        .logout-btn {
            background: none;
            border: none;
            color: #666;
            margin-top: 20px;
            cursor: pointer;
            transition: color 0.3s;
        }

        .logout-btn:hover {
            color: #333;
        }
    </style>
</head>
<body>


    <div class="dashboard-card">
        <div class="welcome-message">
            <?php if (isset($_SESSION['user_id'])): ?>
                <h1>
                    <i class="fas fa-user-circle"></i> Bienvenue,  
                    <?php echo htmlspecialchars($_SESSION['user_nom']); ?>
                </h1>
            <?php else: ?>
                <p>Que souhaitez-vous faire aujourd'hui ?</p>
            <?php endif; ?>
        </div>

        <a href="demande.php" class="action-btn">
            <i class="fas fa-file-alt"></i> Nouvelle demande
        </a>

        <a href="Acceuil.php" class="action-btn">
            <i class="fas fa-home"></i> Accueil
        </a>

        <a href="contacts.php" class="action-btn">
            <i class="fas fa-envelope"></i> Contactez-nous
        </a>

        <!-- Bouton déconnexion -->
        <button class="logout-btn" onclick="window.location.href='?action=logout'">
            <i class="fas fa-sign-out-alt"></i> Déconnexion
        </button>
    </div>
</body>
</html>
