<?php
// Connexion à la base de données
try {
    $pdo = new PDO('mysql:host=localhost;dbname=supercar;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Erreur de connexion : ' . $e->getMessage());
}

// Récupération des images
$stmt = $pdo->query("SELECT * FROM images ORDER BY id ASC");
$images = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Galerie de voitures</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .galerie {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }
        .carte {
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .carte img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .carte h3 {
            margin: 10px 0;
        }
        .carte p {
            color: #666;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<h1 style="text-align:center;">Galerie des voitures BMW</h1>

<div class="galerie">
    <?php foreach ($images as $image): ?>
        <div class="carte">
            <img src="<?= htmlspecialchars($image['chemin']) ?>" alt="<?= htmlspecialchars($image['nom']) ?>">
            <h3><?= htmlspecialchars($image['nom']) ?></h3>
            
        </div>
    <?php endforeach; ?>
</div>

</body>
</html>
