<?php
session_start();
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset(); session_destroy();
    header("Location: Acceuil.php"); exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Accueil – SuperCar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .video-background { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; object-fit: cover; z-index: -1; }
        .hero-wrap { position: relative; overflow: hidden; height: 100vh; display: flex; align-items: center; justify-content: center; }
        .overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(44,44,44,0.02); }
        .ftco-about { position: relative; background: rgba(87,86,86,0.598); z-index: 5; }
        .dropdown-menu { border-radius: 10px; border: none; box-shadow: 0 8px 24px rgba(0,0,0,0.12); min-width: 180px; padding: 8px 0; }
        .dropdown-item { padding: 9px 18px; font-size: 0.9rem; transition: background 0.15s; }
        .dropdown-item:hover { background: #f0faf6; color: #12906c; }
        .dropdown-item.text-danger:hover { background: #fff0f0; color: #dc3545 !important; }
        .dropdown-divider { margin: 4px 0; }
    </style>
</head>
<body>

<?php require_once 'navbar_fragment.php'; ?>

<div class="hero-wrap">
    <video autoplay loop muted playsinline class="video-background">
        <source src="video/car on index.mp4" type="video/mp4">
    </video>
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text justify-content-center align-items-center">
            <div class="col-lg-8 ftco-animate">
                <div class="text w-100 text-center mb-md-5 pb-md-5">
                    <h1 class="mb-4">Un moyen rapide et facile d'acheter une voiture</h1>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="ftco-section ftco-about">
    <div class="container">
        <div class="row no-gutters">
            <div class="col-md-6 p-md-5 img img-2 d-flex justify-content-center align-items-center"
                 style="background-image: url(images/Aboutlogo.png);"></div>
            <div class="col-md-6 wrap-about ftco-animate">
                <div class="heading-section heading-section-white pl-md-5">
                    <h2 class="mb-4">À propos de nous</h2>
                    <p>Votre solution premium pour la location de voitures de luxe et de haute performance. Découvrez notre sélection exclusive de BMW, Mercedes et Toyota, soigneusement entretenues et prêtes à vous offrir une expérience de conduite inoubliable.</p>
                    <p>Explorez notre site et trouvez le véhicule qui correspond à votre style, pour vivre la route comme jamais auparavant !</p>
                    <a href="car.php" class="btn btn-primary py-3 px-4">Rechercher un véhicule</a>
                </div>
            </div>
        </div>
    </div>
</section>

<div id="ftco-loader" class="show fullscreen">
    <svg class="circular" width="20px" height="10px">
        <circle class="path-bg" cx="24" cy="24" r="18" fill="none" stroke-width="4" stroke="#eeeeee"/>
        <circle class="path" cx="24" cy="24" r="18" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/>
    </svg>
</div>

<footer style="background: linear-gradient(135deg, #021638cc, #12906c, #021638cc); color: white; padding: 1.5rem 0; text-align: center; font-family: 'Segoe UI', sans-serif; margin-top: 3rem; box-shadow: 0 -5px 15px rgba(0,0,0,0.1);">
    <div style="max-width:1200px; margin:0 auto; padding:0 20px;">
        <p style="margin:0; font-size:1.1rem;">&copy; SUPERCAR 2024-2026 | By Student MCCI | SIO</p>
        <div style="margin-top:1rem; display:flex; justify-content:center; gap:1.5rem;">
            <a href="contacts.php" style="color:white; text-decoration:none;"><i class="fas fa-envelope"></i> Contact</a>
            <a href="confidentialité.html" style="color:white; text-decoration:none;"><i class="fas fa-shield-alt"></i> Confidentialité</a>
            <a href="Mention.html" style="color:white; text-decoration:none;"><i class="fas fa-file-alt"></i> Mentions légales</a>
        </div>
    </div>
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>
