<?php
session_start();

// Protection : doit être connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php");
    exit();
}

// Récupérer les champs du formulaire direct
$nom        = trim($_POST['nom']        ?? '');
$prenom     = trim($_POST['prenom']     ?? '');
$email      = trim($_POST['email']      ?? '');
$voiture_id = trim($_POST['voiture_id'] ?? '');
$voiture_nom= trim($_POST['voiture_nom']?? '');
$lieurecup  = trim($_POST['lieurecup']  ?? '');
$lieudepot  = trim($_POST['lieudepot']  ?? '');
$daterecup  = trim($_POST['daterecup']  ?? '');
$datedepot  = trim($_POST['datedepot']  ?? '');
$heurerecup = trim($_POST['heurerecup'] ?? '');

// Validation basique
if (!$nom || !$prenom || !$email || !$voiture_id || !$daterecup || !$datedepot || !$heurerecup) {
    header("Location: demande.php?erreur=champs_manquants");
    exit();
}

// Connexion BDD
$conn = mysqli_connect("localhost", "root", "", "supercar");
if (!$conn) die("Échec connexion : " . mysqli_connect_error());

$nom_e        = mysqli_real_escape_string($conn, $nom);
$prenom_e     = mysqli_real_escape_string($conn, $prenom);
$email_e      = mysqli_real_escape_string($conn, $email);
$voiture_id_e = mysqli_real_escape_string($conn, $voiture_id);
$voiture_nom_e= mysqli_real_escape_string($conn, $voiture_nom);
$lieurecup_e  = mysqli_real_escape_string($conn, $lieurecup);
$lieudepot_e  = mysqli_real_escape_string($conn, $lieudepot);
$daterecup_e  = mysqli_real_escape_string($conn, $daterecup);
$datedepot_e  = mysqli_real_escape_string($conn, $datedepot);
$heurerecup_e = mysqli_real_escape_string($conn, $heurerecup);

$sql = "INSERT INTO essai (nom, prenom, email, voiture_id, voiture_nom, lieurecup, lieudepot, daterecup, datedepot, heurerecup)
        VALUES ('$nom_e','$prenom_e','$email_e','$voiture_id_e','$voiture_nom_e',
                '$lieurecup_e','$lieudepot_e','$daterecup_e','$datedepot_e','$heurerecup_e')";

$succes  = mysqli_query($conn, $sql) ? 1 : 0;
$erreurs = $succes ? 0 : 1;
mysqli_close($conn);

// Préparer le récap pour la page de confirmation
$details = [];
if ($succes) {
    $details[] = [
        'voiture_nom' => htmlspecialchars($voiture_nom),
        'daterecup'   => $daterecup,
        'datedepot'   => $datedepot,
        'lieurecup'   => $lieurecup,
        'lieudepot'   => $lieudepot,
    ];
}

// Couleurs selon résultat
if ($succes) {
    $titre       = "Demande enregistrée !";
    $message     = "Votre demande d'essai pour <strong>" . htmlspecialchars($voiture_nom) . "</strong> a bien été prise en compte. Nous reviendrons vers vous prochainement.";
    $color_start = "#00ff88"; $color_end = "#00cc6a";
    $glow = "rgba(0,255,136,0.6)"; $glow_light = "rgba(0,255,136,0.3)"; $glow_mid = "rgba(0,255,136,0.4)";
} else {
    $titre   = "Erreur lors de l'envoi";
    $message = "Impossible d'enregistrer votre demande. Veuillez réessayer.";
    $color_start = "#fc8181"; $color_end = "#e53e3e";
    $glow = "rgba(229,62,62,0.6)"; $glow_light = "rgba(229,62,62,0.3)"; $glow_mid = "rgba(229,62,62,0.4)";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation – SuperCar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body, html { height:100%; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color:white; overflow-x:hidden; }
        .video-background { position:fixed; top:0; left:0; min-width:100%; min-height:100%; z-index:-1; object-fit:cover; filter:brightness(0.7); }
        .overlay { position:fixed; top:0; left:0; width:100%; height:100%; background:radial-gradient(circle at center, rgba(0,255,136,0.1) 0%, rgba(0,0,0,0.7) 100%); z-index:0; }
        .decorative-lines { position:fixed; width:100%; height:100%; top:0; left:0; z-index:0; pointer-events:none; overflow:hidden; }
        .line { position:absolute; background:linear-gradient(90deg, transparent, rgba(0,255,136,0.3), transparent); animation:moveLine 15s linear infinite; }
        .line:nth-child(1) { width:100%; height:2px; top:20%; animation-delay:0s; }
        .line:nth-child(2) { width:100%; height:2px; top:60%; animation-delay:5s; }
        .line:nth-child(3) { width:2px; height:100%; left:30%; background:linear-gradient(180deg, transparent, rgba(0,255,136,0.3), transparent); animation:moveLineVertical 12s linear infinite; animation-delay:3s; }
        @keyframes moveLine         { 0% { transform:translateX(-100%); } 100% { transform:translateX(100%); } }
        @keyframes moveLineVertical { 0% { transform:translateY(-100%); } 100% { transform:translateY(100%); } }
        .confirmation-container { position:relative; z-index:1; display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:100vh; text-align:center; padding:40px 20px; }
        .success-icon { width:120px; height:120px; border-radius:50%; background:linear-gradient(135deg, <?= $color_start ?>, <?= $color_end ?>); display:flex; align-items:center; justify-content:center; margin-bottom:30px; box-shadow:0 0 50px <?= $glow ?>, 0 0 100px <?= $glow_light ?>; animation:pulse 2s ease-in-out infinite, iconAppear 0.8s ease-out; }
        .success-icon svg { width:70px; height:70px; stroke:white; stroke-width:3; fill:none; stroke-linecap:round; stroke-linejoin:round; }
        @keyframes pulse { 0%,100% { transform:scale(1); box-shadow:0 0 50px <?= $glow ?>, 0 0 100px <?= $glow_light ?>; } 50% { transform:scale(1.05); box-shadow:0 0 70px <?= $glow ?>, 0 0 120px <?= $glow_mid ?>; } }
        @keyframes iconAppear { from { transform:scale(0) rotate(-180deg); opacity:0; } to { transform:scale(1) rotate(0deg); opacity:1; } }
        .confirmation-title { font-size:52px; font-weight:900; margin-bottom:20px; background:linear-gradient(135deg, <?= $color_start ?>, #00ffcc, <?= $color_start ?>); background-size:200% 200%; -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; animation:gradientShift 3s ease infinite, titleAppear 1s ease-out 0.3s backwards; letter-spacing:2px; text-transform:uppercase; }
        @keyframes gradientShift { 0%,100% { background-position:0% 50%; } 50% { background-position:100% 50%; } }
        @keyframes titleAppear { from { opacity:0; transform:translateY(30px); } to { opacity:1; transform:translateY(0); } }
        .confirmation-message { font-size:20px; margin-bottom:30px; max-width:700px; line-height:1.6; text-shadow:2px 2px 8px rgba(0,0,0,0.8); animation:messageAppear 1s ease-out 0.6s backwards; font-weight:300; }
        @keyframes messageAppear { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
        .recap-container { width:100%; max-width:500px; margin-bottom:35px; animation:messageAppear 1s ease-out 0.75s backwards; }
        .recap-card { background:rgba(255,255,255,0.1); backdrop-filter:blur(10px); border:1px solid rgba(255,255,255,0.2); border-radius:16px; padding:20px; text-align:left; }
        .recap-card .car-badge { display:inline-block; background:linear-gradient(135deg, <?= $color_start ?>, <?= $color_end ?>); color:#000; font-weight:700; font-size:0.7rem; padding:3px 10px; border-radius:20px; margin-bottom:10px; }
        .recap-card .car-name { font-size:1.1rem; font-weight:700; margin-bottom:10px; }
        .recap-card .recap-detail { font-size:0.85rem; color:rgba(255,255,255,0.75); margin-bottom:6px; display:flex; align-items:center; gap:8px; }
        .buttons-container { display:flex; gap:20px; flex-wrap:wrap; justify-content:center; animation:messageAppear 1s ease-out 0.9s backwards; }
        .btn { padding:16px 36px; font-size:17px; font-weight:600; text-decoration:none; color:white; background:linear-gradient(135deg, #007BFF, #0056b3); border:2px solid rgba(255,255,255,0.2); border-radius:50px; cursor:pointer; transition:all 0.4s ease; display:inline-block; box-shadow:0 8px 25px rgba(0,123,255,0.4); }
        .btn:hover { transform:translateY(-5px); box-shadow:0 15px 40px rgba(0,123,255,0.6); color:white; text-decoration:none; }
        @media (max-width:768px) { .confirmation-title { font-size:30px; } .confirmation-message { font-size:17px; } .success-icon { width:90px; height:90px; } .success-icon svg { width:50px; height:50px; } .buttons-container { flex-direction:column; width:100%; } .btn { width:100%; max-width:300px; } }
    </style>
</head>
<body>
    <video autoplay muted loop class="video-background">
        <source src="video/Demande reussi .mp4" type="video/mp4">
    </video>
    <div class="overlay"></div>
    <div class="decorative-lines">
        <div class="line"></div><div class="line"></div><div class="line"></div>
    </div>

    <div class="confirmation-container">
        <div class="success-icon">
            <?php if ($succes): ?>
                <svg viewBox="0 0 52 52"><path d="M14 27l7 7 16-16"/></svg>
            <?php else: ?>
                <svg viewBox="0 0 52 52"><path d="M16 16l20 20M36 16l-20 20"/></svg>
            <?php endif; ?>
        </div>

        <div class="confirmation-title"><?= htmlspecialchars($titre) ?></div>
        <div class="confirmation-message"><?= $message ?></div>

        <?php if (!empty($details)): $d = $details[0]; ?>
        <div class="recap-container">
            <div class="recap-card">
                <span class="car-badge"><i class="fas fa-car"></i> Essai</span>
                <div class="car-name"><?= $d['voiture_nom'] ?></div>
                <div class="recap-detail">
                    <i class="fas fa-calendar-alt"></i>
                    Du <?= date('d/m/Y', strtotime($d['daterecup'])) ?> au <?= date('d/m/Y', strtotime($d['datedepot'])) ?>
                </div>
                <?php if (!empty($d['lieurecup'])): ?>
                <div class="recap-detail">
                    <i class="fas fa-map-marker-alt"></i>
                    <?= htmlspecialchars($d['lieurecup']) ?>
                    <?php if (!empty($d['lieudepot'])): ?> → <?= htmlspecialchars($d['lieudepot']) ?><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="buttons-container">
            <a class="btn" href="Acceuil.php">Retour à l'accueil</a>
            <a class="btn" href="car.php">Voir les voitures</a>
        </div>
    </div>
</body>
</html>
