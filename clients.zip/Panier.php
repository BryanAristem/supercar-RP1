<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php");
    exit();
}

$user_nom = $_SESSION['user_nom'] ?? 'Utilisateur';

if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

// Connexion BDD pour récupérer la photo de chaque voiture
$host = "localhost"; $login = "root"; $pass = ""; $bdd = "supercar";
$conn = mysqli_connect($host, $login, $pass, $bdd);

$panier    = $_SESSION['panier'];
$nb_panier = count($panier);

// Récupérer la photo de chaque voiture du panier
foreach ($panier as &$item) {
    $vid = mysqli_real_escape_string($conn, $item['voiture_id']);
    $res = mysqli_query($conn, "SELECT photo FROM voiture WHERE id = '$vid' LIMIT 1");
    $row = $res ? mysqli_fetch_assoc($res) : null;
    $item['photo'] = $row['photo'] ?? null; // Contient déjà "images/bmwx5.jpeg"
}
unset($item);
mysqli_close($conn);

// Messages
$message = ''; $message_type = '';
if (isset($_GET['succes'])) {
    switch ($_GET['succes']) {
        case 'supprime': $message = "🗑️ Demande supprimée du panier."; $message_type = 'warning'; break;
        case 'vide':     $message = "🗑️ Panier vidé.";                 $message_type = 'warning'; break;
        case 'envoye':   $message = "✅ Toutes vos demandes ont été envoyées avec succès !"; $message_type = 'success'; break;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Mon panier d'essais</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        .panier-nav-link {
            position: relative; display: inline-flex; align-items: center;
            color: rgba(255,255,255,0.7); text-decoration: none;
            padding: 0.5rem 1rem; transition: color 0.2s;
        }
        .panier-nav-link:hover { color: #fff; text-decoration: none; }
        .panier-nav-link i { font-size: 1.3rem; }
        .panier-badge {
            position: absolute; top: 2px; right: 4px;
            background: #e74c3c; color: white; border-radius: 50%;
            font-size: 0.65rem; font-weight: 700; width: 18px; height: 18px;
            display: flex; align-items: center; justify-content: center;
        }
        .panier-badge.hidden { display: none; }

        .toast-notification {
            position: fixed; top: 90px; right: 20px; z-index: 9999;
            max-width: 380px; border-radius: 10px; padding: 14px 20px;
            font-size: 0.95rem; box-shadow: 0 6px 20px rgba(0,0,0,0.15);
            animation: slideInRight 0.4s ease;
        }
        .toast-notification.success { background: #d4edda; color: #155724; border-left: 4px solid #28a745; }
        .toast-notification.warning { background: #fff3cd; color: #856404; border-left: 4px solid #ffc107; }
        @keyframes slideInRight { from { transform: translateX(120%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

        .panier-page { padding: 3rem 0; min-height: 70vh; }
        .panier-header {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem;
        }
        .panier-header h2 { margin: 0; font-size: 1.8rem; color: #2d3748; font-weight: 700; }
        .panier-header .subtitle { color: #718096; font-size: 0.95rem; margin-top: 4px; }

        .car-card {
            display: flex;
            background: white;
            border-radius: 18px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            margin-bottom: 1.4rem;
            overflow: hidden;
            border: 1px solid #e8edf3;
            transition: transform 0.25s, box-shadow 0.25s;
            min-height: 160px;
        }
        .car-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,0,0,0.13); }

        .car-card-photo {
            position: relative; width: 220px; min-width: 220px;
            flex-shrink: 0; overflow: hidden; background: #1a1a2e;
        }
        .car-card-photo img {
            width: 100%; height: 100%; object-fit: cover;
            display: block; transition: transform 0.4s ease;
        }
        .car-card:hover .car-card-photo img { transform: scale(1.06); }

        .car-photo-label {
            position: absolute; bottom: 0; left: 0; right: 0;
            background: linear-gradient(to top, rgba(0,0,0,0.85) 0%, transparent 100%);
            padding: 28px 12px 10px; color: white;
            font-weight: 700; font-size: 0.92rem; letter-spacing: 0.3px;
        }
        .car-photo-fallback {
            width: 100%; height: 100%; display: flex; flex-direction: column;
            align-items: center; justify-content: center;
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            color: rgba(255,255,255,0.5); font-size: 3rem; gap: 8px;
        }
        .car-photo-fallback span {
            font-size: 0.75rem; font-weight: 600;
            color: rgba(255,255,255,0.6); text-align: center; padding: 0 10px;
        }
        .essai-badge {
            position: absolute; top: 10px; left: 10px;
            background: linear-gradient(135deg, #12906c, #20c997);
            color: white; font-weight: 700; font-size: 0.7rem;
            padding: 3px 9px; border-radius: 20px; letter-spacing: 0.5px;
        }

        .car-card-info {
            flex: 1; padding: 18px 20px; display: flex;
            flex-direction: column; justify-content: space-between;
        }
        .car-info-rows { display: flex; flex-direction: column; gap: 10px; }
        .car-info-row { display: flex; align-items: center; gap: 10px; }
        .car-info-row .info-icon {
            width: 32px; height: 32px; border-radius: 8px; background: #f0fdf9;
            display: flex; align-items: center; justify-content: center; flex-shrink: 0;
        }
        .car-info-row .info-icon i { color: #12906c; font-size: 0.85rem; }
        .car-info-row .info-text label {
            display: block; font-size: 0.68rem; font-weight: 600;
            color: #a0aec0; text-transform: uppercase; letter-spacing: 0.4px; margin-bottom: 1px;
        }
        .car-info-row .info-text span { font-size: 0.92rem; font-weight: 600; color: #2d3748; }

        .car-card-actions {
            display: flex; gap: 8px; margin-top: 14px;
            padding-top: 12px; border-top: 1px solid #f0f4f8;
        }
        .btn-details {
            flex: 1; background: linear-gradient(135deg, #12906c, #20c997);
            color: white; border: none; padding: 8px 0; border-radius: 8px;
            font-size: 0.82rem; font-weight: 600; cursor: pointer; transition: all 0.2s;
            display: flex; align-items: center; justify-content: center; gap: 5px;
        }
        .btn-details:hover { opacity: 0.88; transform: translateY(-1px); }
        .btn-suppr {
            background: none; border: 1px solid #feb2b2; color: #e53e3e;
            padding: 8px 14px; border-radius: 8px; font-size: 0.82rem;
            cursor: pointer; transition: all 0.2s;
            display: flex; align-items: center; gap: 5px; text-decoration: none;
        }
        .btn-suppr:hover { background: #e53e3e; color: white; border-color: #e53e3e; text-decoration: none; }

        .panier-vide { text-align: center; padding: 5rem 2rem; color: #718096; }
        .panier-vide i { font-size: 5rem; opacity: 0.15; margin-bottom: 1.5rem; display: block; }
        .panier-vide h3 { font-size: 1.4rem; color: #4a5568; }

        .panier-summary {
            background: white; border-radius: 16px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.08);
            padding: 24px; border: 1px solid #e2e8f0; position: sticky; top: 100px;
        }
        .panier-summary h4 { font-weight: 700; color: #2d3748; margin-bottom: 1.2rem; }
        .slots-visual { display: flex; gap: 8px; margin-bottom: 1rem; }
        .slot-dot { flex: 1; height: 8px; border-radius: 4px; background: #e2e8f0; transition: background 0.3s; }
        .slot-dot.filled { background: linear-gradient(135deg, #12906c, #20c997); }
        .summary-line {
            display: flex; justify-content: space-between;
            font-size: 0.9rem; color: #4a5568;
            padding: 8px 0; border-bottom: 1px solid #f0f0f0;
        }
        .summary-line:last-of-type { border-bottom: none; font-weight: 700; color: #2d3748; font-size: 1rem; }
        .btn-valider {
            display: block; width: 100%;
            background: linear-gradient(135deg, #12906c, #20c997);
            color: white; border: none; padding: 14px; border-radius: 10px;
            font-size: 1rem; font-weight: 700; cursor: pointer; margin-top: 1.2rem;
            transition: all 0.3s; text-align: center; text-decoration: none;
        }
        .btn-valider:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(18,144,108,0.4); color: white; text-decoration: none; }
        .btn-ajouter {
            display: block; width: 100%; margin-top: 0.8rem;
            background: white; color: #12906c; border: 2px solid #12906c;
            padding: 10px; border-radius: 10px; font-size: 0.9rem; font-weight: 600;
            text-align: center; text-decoration: none; transition: all 0.2s;
        }
        .btn-ajouter:hover { background: #f0fdf4; text-decoration: none; color: #0e7057; }
        .btn-vider {
            display: block; width: 100%; margin-top: 0.5rem;
            background: none; color: #e53e3e; border: none; font-size: 0.85rem;
            cursor: pointer; text-align: center; transition: color 0.2s;
        }
        .btn-vider:hover { color: #c53030; text-decoration: underline; }

        .modal-overlay {
            display: none; position: fixed; inset: 0; z-index: 10000;
            background: rgba(15, 20, 40, 0.7); backdrop-filter: blur(4px);
            align-items: center; justify-content: center; padding: 20px;
        }
        .modal-overlay.open { display: flex; animation: fadeInOverlay 0.2s ease; }
        @keyframes fadeInOverlay { from { opacity: 0; } to { opacity: 1; } }

        .modal-box {
            background: white; border-radius: 20px; max-width: 540px; width: 100%;
            box-shadow: 0 24px 60px rgba(0,0,0,0.25); overflow: hidden; animation: slideUp 0.3s ease;
        }
        @keyframes slideUp { from { transform: translateY(40px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

        .modal-photo { position: relative; height: 200px; overflow: hidden; background: #1a1a2e; }
        .modal-photo img { width: 100%; height: 100%; object-fit: cover; }
        .modal-photo-overlay {
            position: absolute; inset: 0;
            background: linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 60%);
        }
        .modal-photo-title { position: absolute; bottom: 16px; left: 20px; color: white; font-size: 1.3rem; font-weight: 800; }
        .modal-close-btn {
            position: absolute; top: 12px; right: 12px;
            background: rgba(255,255,255,0.2); border: none; color: white;
            width: 32px; height: 32px; border-radius: 50%; cursor: pointer;
            font-size: 1rem; display: flex; align-items: center; justify-content: center;
            transition: background 0.2s; backdrop-filter: blur(4px);
        }
        .modal-close-btn:hover { background: rgba(255,255,255,0.4); }

        .modal-body { padding: 22px 24px 24px; }
        .modal-badge {
            display: inline-block; margin-bottom: 14px;
            background: linear-gradient(135deg, #12906c, #20c997);
            color: white; font-size: 0.72rem; font-weight: 700;
            padding: 4px 12px; border-radius: 20px; letter-spacing: 0.5px;
        }
        .modal-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px 20px; }
        .modal-field label {
            display: block; font-size: 0.7rem; font-weight: 700;
            color: #a0aec0; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 3px;
        }
        .modal-field span { font-size: 0.95rem; font-weight: 600; color: #2d3748; }
        .modal-field.full { grid-column: 1 / -1; }

        .modal-footer {
            padding: 14px 24px 20px; display: flex; gap: 10px;
            justify-content: flex-end; border-top: 1px solid #f0f4f8;
        }
        .modal-btn-close {
            background: #f7fafc; color: #4a5568; border: 1px solid #e2e8f0;
            padding: 9px 20px; border-radius: 8px; font-size: 0.9rem; font-weight: 600;
            cursor: pointer; transition: all 0.2s;
        }
        .modal-btn-close:hover { background: #edf2f7; }
        .modal-btn-suppr {
            background: none; border: 1px solid #e53e3e; color: #e53e3e;
            padding: 9px 20px; border-radius: 8px; font-size: 0.9rem; font-weight: 600;
            cursor: pointer; transition: all 0.2s; text-decoration: none;
            display: flex; align-items: center; gap: 6px;
        }
        .modal-btn-suppr:hover { background: #e53e3e; color: white; text-decoration: none; }

        @media (max-width: 768px) {
            .car-card { flex-direction: column; }
            .car-card-photo { width: 100%; min-width: unset; height: 180px; }
            .modal-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<?php if ($message): ?>
<div class="toast-notification <?= $message_type ?>" id="toast-msg">
    <?= $message ?>
    <button onclick="document.getElementById('toast-msg').style.display='none'"
            style="background:none;border:none;float:right;cursor:pointer;font-size:1.1rem;margin-left:10px;color:inherit;">×</button>
</div>
<script>setTimeout(() => { const t = document.getElementById('toast-msg'); if(t) t.style.display='none'; }, 5000);</script>
<?php endif; ?>

<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container-fluid px-0">
        <a class="navbar-brand ml-lg-5 ml-3" href="index.html" style="margin-right: -50px;">Super<span>car</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
            <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">

            <!-- ── LIENS CENTRE ──────────────────────────────── -->
            <ul class="navbar-nav mx-auto" style="max-width: 600px; width: 100%; display: flex; flex-wrap: nowrap;">
                <li class="nav-item active"><a href="Acceuil.php" class="nav-link">Accueil</a></li>
                <li class="nav-item"><a href="car.php" class="nav-link">Voitures</a></li>
                <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
                <li class="nav-item" style="display: inline-flex;">
                    <a href="demande.php" class="nav-link" style="white-space: nowrap;">Demande d'essai</a>
                    <span style="color: rgba(255,255,255,0.5); margin: 0 5px;"></span>
                    <a href="contacts.php" class="nav-link" style="white-space: nowrap;">Contactez-nous</a>
                </li>
            </ul>

            <!-- ── PARTIE DROITE ─────────────────────────────── -->
            <ul class="navbar-nav" style="margin-right: 50px;">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php
                        $photo_nav = $_SESSION['user_photo'] ?? '';
                        $nom_nav   = $_SESSION['user_nom'] ?? 'Utilisateur';
                    ?>

                    <!-- 1. Icône panier (HORS du dropdown-toggle) -->
                    <li class="nav-item">
                        <a href="panier.php" class="panier-nav-link" title="Mon panier d'essais">
                            <i class="fas fa-shopping-cart"></i>
                            <span class="panier-badge <?= $nb_panier === 0 ? 'hidden' : '' ?>">
                                <?= $nb_panier ?>
                            </span>
                        </a>
                    </li>

                    <!-- 2. Dropdown avatar + nom (sans flèche) -->
                    <li class="nav-item dropdown">
                        <a class="nav-link user-dropdown-toggle" href="#"
                           id="userDropdown" role="button"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="<?= !empty($photo_nav) ? htmlspecialchars($photo_nav) : 'https://ui-avatars.com/api/?name=' . urlencode($nom_nav) . '&background=12906c&color=fff&size=40' ?>"
                                 style="width:34px; height:34px; border-radius:50%; object-fit:cover; border:2px solid #12906c;">
                            <span><?= htmlspecialchars($nom_nav) ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="profil.php">
                                <i class="fas fa-user mr-2"></i> Mon profil
                            </a>
                            <a class="dropdown-item" href="panier.php">
                                <i class="fas fa-shopping-cart mr-2"></i> Mon panier
                                <?php if ($nb_panier > 0): ?>
                                    <span class="badge badge-success ml-1"><?= $nb_panier ?></span>
                                <?php endif; ?>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt mr-2"></i> Déconnexion
                            </a>
                        </div>
                    </li>

                <?php else: ?>
                    <li class="nav-item">
                        <a href="connexion.php" class="nav-link">
                            <i class="fas fa-sign-in-alt"></i> Se connecter
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

        </div>
    </div>
</nav>

<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image:url('images/cardealership.jpg');" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
            <div class="col-md-9 ftco-animate pb-5">
                <p class="breadcrumbs">
                    <span class="mr-2"><a href="index.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span>
                    <span class="mr-2"><a href="demande.php">Demande d'essai <i class="ion-ios-arrow-forward"></i></a></span>
                    <span>Mon panier <i class="ion-ios-arrow-forward"></i></span>
                </p>
                <h1 class="mb-3 bread">Mon panier d'essais</h1>
            </div>
        </div>
    </div>
</section>

<section class="panier-page bg-light">
    <div class="container">
        <?php if ($nb_panier === 0): ?>
            <div class="panier-vide">
                <i class="fas fa-shopping-cart"></i>
                <h3>Votre panier est vide</h3>
                <p>Vous n'avez pas encore ajouté de demande d'essai.</p>
                <a href="demande.php" class="btn btn-primary mt-3">
                    <i class="fas fa-plus mr-2"></i> Faire une demande d'essai
                </a>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-lg-8">
                    <div class="panier-header">
                        <div>
                            <h2><i class="fas fa-shopping-cart mr-2" style="color:#12906c;"></i> Mon Panier</h2>
                            <p class="subtitle"><?= $nb_panier ?> demande<?= $nb_panier > 1 ? 's' : '' ?> d'essai en attente</p>
                        </div>
                        <a href="demande.php" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-plus mr-1"></i> Ajouter
                        </a>
                    </div>

                    <?php foreach ($panier as $i => $item):
                        $photo       = $item['photo'] ?? null;
                        $nom_voiture = htmlspecialchars($item['voiture_nom']);
                        $demandeur   = htmlspecialchars($item['prenom'] . ' ' . $item['nom']);
                        $date_r      = date('d/m/Y', strtotime($item['daterecup']));
                        $heure_r     = htmlspecialchars($item['heurerecup']);
                    ?>
                    <div class="car-card">
                        <div class="car-card-photo">
                            <span class="essai-badge">Essai #<?= $i + 1 ?></span>

                            <?php if ($photo): ?>
                                <?php
                                // ✅ CORRECTION CLÉE :
                                // La BDD stocke déjà "images/bmwx5.jpeg"
                                // On utilise $photo DIRECTEMENT, sans rajouter "images/" devant
                                ?>
                                <img src="<?= htmlspecialchars($photo) ?>" alt="<?= $nom_voiture ?>">
                            <?php else: ?>
                                <div class="car-photo-fallback">
                                    <i class="fas fa-car"></i>
                                    <span><?= $nom_voiture ?></span>
                                </div>
                            <?php endif; ?>

                            <div class="car-photo-label"><?= $nom_voiture ?></div>
                        </div>

                        <div class="car-card-info">
                            <div class="car-info-rows">
                                <div class="car-info-row">
                                    <div class="info-icon"><i class="fas fa-user"></i></div>
                                    <div class="info-text">
                                        <label>Demandeur</label>
                                        <span><?= $demandeur ?></span>
                                    </div>
                                </div>
                                <div class="car-info-row">
                                    <div class="info-icon"><i class="fas fa-calendar-alt"></i></div>
                                    <div class="info-text">
                                        <label>Date de récupération</label>
                                        <span><?= $date_r ?></span>
                                    </div>
                                </div>
                                <div class="car-info-row">
                                    <div class="info-icon"><i class="fas fa-clock"></i></div>
                                    <div class="info-text">
                                        <label>Heure de récupération</label>
                                        <span><?= $heure_r ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="car-card-actions">
                                <button class="btn-details" onclick="openModal(<?= $i ?>)">
                                    <i class="fas fa-eye"></i> Voir les détails
                                </button>
                                <a href="panier_action.php?action=supprimer&id=<?= urlencode($item['id']) ?>"
                                   class="btn-suppr"
                                   onclick="return confirm('Supprimer cette demande ?')">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="col-lg-4 mt-4 mt-lg-0">
                    <div class="panier-summary">
                        <h4><i class="fas fa-receipt mr-2" style="color:#12906c;"></i> Résumé</h4>
                        <div class="slots-visual">
                            <div class="slot-dot <?= $nb_panier >= 1 ? 'filled' : '' ?>"></div>
                            <div class="slot-dot <?= $nb_panier >= 2 ? 'filled' : '' ?>"></div>
                            <div class="slot-dot <?= $nb_panier >= 3 ? 'filled' : '' ?>"></div>
                        </div>
                        <?php foreach ($panier as $i => $item): ?>
                        <div class="summary-line">
                            <span><i class="fas fa-car mr-1" style="color:#12906c;"></i> Essai #<?= $i+1 ?></span>
                            <span><?= htmlspecialchars($item['voiture_nom']) ?></span>
                        </div>
                        <?php endforeach; ?>
                        <div class="summary-line">
                            <span>Total demandes</span>
                            <span><?= $nb_panier ?>/3</span>
                        </div>
                        <form action="Confirmation_demander.php" method="POST">
                            <?php foreach ($panier as $i => $item): ?>
                                <?php foreach ($item as $key => $val): ?>
                                    <input type="hidden" name="demandes[<?= $i ?>][<?= htmlspecialchars($key) ?>]"
                                           value="<?= htmlspecialchars($val) ?>">
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                            <button type="submit" class="btn-valider">
                                <i class="fas fa-check-circle mr-2"></i> Valider mes demandes
                            </button>
                        </form>
                        <?php if ($nb_panier < 3): ?>
                        <a href="demande.php" class="btn-ajouter">
                            <i class="fas fa-plus mr-1"></i> Ajouter (<?= 3 - $nb_panier ?> restant<?= (3-$nb_panier)>1?'s':'' ?>)
                        </a>
                        <?php endif; ?>
                        <a href="panier_action.php?action=vider"
                           class="btn-vider"
                           onclick="return confirm('Vider tout le panier ?')">
                            <i class="fas fa-trash mr-1"></i> Vider le panier
                        </a>
                    </div>
                </div>
            </div>

            <!-- MODALES -->
            <?php foreach ($panier as $i => $item):
                $photo       = $item['photo'] ?? null;
                $nom_voiture = htmlspecialchars($item['voiture_nom']);
            ?>
            <div class="modal-overlay" id="modal-<?= $i ?>">
                <div class="modal-box">
                    <div class="modal-photo">
                        <?php if ($photo): ?>
                            <?php
                            // ✅ CORRECTION CLÉE (modale) :
                            // Même chose : $photo contient déjà "images/xxx.jpg"
                            // Pas besoin d'ajouter "images/" devant
                            ?>
                            <img src="<?= htmlspecialchars($photo) ?>" alt="<?= $nom_voiture ?>">
                        <?php else: ?>
                            <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,0.3);font-size:4rem;">
                                <i class="fas fa-car"></i>
                            </div>
                        <?php endif; ?>
                        <div class="modal-photo-overlay"></div>
                        <div class="modal-photo-title"><?= $nom_voiture ?></div>
                        <button class="modal-close-btn" onclick="closeModal(<?= $i ?>)">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>

                    <div class="modal-body">
                        <span class="modal-badge"><i class="fas fa-car mr-1"></i> Essai #<?= $i + 1 ?></span>
                        <div class="modal-grid">
                            <div class="modal-field">
                                <label><i class="fas fa-user mr-1"></i> Nom</label>
                                <span><?= htmlspecialchars($item['nom']) ?></span>
                            </div>
                            <div class="modal-field">
                                <label><i class="fas fa-user mr-1"></i> Prénom</label>
                                <span><?= htmlspecialchars($item['prenom']) ?></span>
                            </div>
                            <div class="modal-field full">
                                <label><i class="fas fa-envelope mr-1"></i> Email</label>
                                <span><?= htmlspecialchars($item['email']) ?></span>
                            </div>
                            <div class="modal-field">
                                <label><i class="fas fa-calendar mr-1"></i> Date récupération</label>
                                <span><?= date('d/m/Y', strtotime($item['daterecup'])) ?></span>
                            </div>
                            <div class="modal-field">
                                <label><i class="fas fa-calendar-check mr-1"></i> Date dépôt</label>
                                <span><?= date('d/m/Y', strtotime($item['datedepot'])) ?></span>
                            </div>
                            <div class="modal-field">
                                <label><i class="fas fa-clock mr-1"></i> Heure récupération</label>
                                <span><?= htmlspecialchars($item['heurerecup']) ?></span>
                            </div>
                            <div class="modal-field">
                                <label><i class="fas fa-map-marker-alt mr-1"></i> Lieu récupération</label>
                                <span><?= htmlspecialchars($item['lieurecup'] ?: '—') ?></span>
                            </div>
                            <div class="modal-field">
                                <label><i class="fas fa-map-marker-alt mr-1"></i> Lieu dépôt</label>
                                <span><?= htmlspecialchars($item['lieudepot'] ?: '—') ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="modal-btn-close" onclick="closeModal(<?= $i ?>)">Fermer</button>
                        <a href="panier_action.php?action=supprimer&id=<?= urlencode($item['id']) ?>"
                           class="modal-btn-suppr"
                           onclick="return confirm('Supprimer cette demande ?')">
                            <i class="fas fa-trash-alt"></i> Supprimer
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

        <?php endif; ?>
    </div>
</section>

<footer style="background:linear-gradient(135deg,#247eec,#12906c,#2d73ed);color:white;padding:1.5rem 0;text-align:center;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;margin-top:3rem;box-shadow:0 -5px 15px rgba(0,0,0,0.1);">
    <div style="max-width:1200px;margin:0 auto;padding:0 20px;">
        <p style="margin:0;font-size:1.1rem;letter-spacing:1px;display:flex;justify-content:center;align-items:center;gap:10px;flex-wrap:wrap;">
            <span style="font-weight:bold;">&copy; SUPERCAR 2024-2026</span>
            <span style="color:rgba(255,255,255,0.8);">|</span>
            <span>By Student MCCI</span>
            <span style="color:rgba(255,255,255,0.8);">|</span>
            <span>SIO</span>
        </p>
        <div style="margin-top:1rem;display:flex;justify-content:center;gap:1.5rem;">
            <a href="contacts.php" style="color:white;text-decoration:none;"><i class="fas fa-envelope"></i> Contact</a>
            <a href="confidentialité.html" style="color:white;text-decoration:none;"><i class="fas fa-shield-alt"></i> Confidentialité</a>
            <a href="Mention.html" style="color:white;text-decoration:none;"><i class="fas fa-file-alt"></i> Mentions légales</a>
        </div>
    </div>
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/main.js"></script>

<script>
function openModal(i) {
    document.getElementById('modal-' + i).classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeModal(i) {
    document.getElementById('modal-' + i).classList.remove('open');
    document.body.style.overflow = '';
}
document.querySelectorAll('.modal-overlay').forEach(function(overlay) {
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            overlay.classList.remove('open');
            document.body.style.overflow = '';
        }
    });
});
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.open').forEach(function(m) {
            m.classList.remove('open');
        });
        document.body.style.overflow = '';
    }
});
</script>
</body>
</html>