<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php");
    exit();
}

// Initialiser le panier si pas encore défini
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// ─── AJOUTER AU PANIER ────────────────────────────────────────────────────────
if ($action === 'ajouter') {

    // Vérifier que le panier n'est pas plein (max 3)
    if (count($_SESSION['panier']) >= 3) {
        header("Location: demande.php?erreur=panier_plein");
        exit();
    }

    // Récupérer les données du formulaire
    $voiture_id   = $_POST['voiture_id']   ?? '';
    $voiture_nom  = $_POST['voiture_nom']  ?? '';
    $nom          = $_POST['nom']          ?? '';
    $prenom       = $_POST['prenom']       ?? '';
    $email        = $_POST['email']        ?? '';
    $lieurecup    = $_POST['lieurecup']    ?? '';
    $lieudepot    = $_POST['lieudepot']    ?? '';
    $daterecup    = $_POST['daterecup']    ?? '';
    $datedepot    = $_POST['datedepot']    ?? '';
    $heurerecup   = $_POST['heurerecup']   ?? '';

    // Vérifications basiques
    if (empty($voiture_id) || empty($daterecup) || empty($datedepot) || empty($heurerecup)) {
        header("Location: demande.php?erreur=champs_manquants");
        exit();
    }

    // Vérifier qu'on n'a pas déjà cette voiture aux mêmes dates
    foreach ($_SESSION['panier'] as $item) {
        if ($item['voiture_id'] == $voiture_id && $item['daterecup'] == $daterecup) {
            header("Location: demande.php?erreur=doublon");
            exit();
        }
    }

    // Ajouter au panier
    $_SESSION['panier'][] = [
        'id'         => uniqid(),
        'voiture_id' => $voiture_id,
        'voiture_nom'=> $voiture_nom,
        'nom'        => $nom,
        'prenom'     => $prenom,
        'email'      => $email,
        'lieurecup'  => $lieurecup,
        'lieudepot'  => $lieudepot,
        'daterecup'  => $daterecup,
        'datedepot'  => $datedepot,
        'heurerecup' => $heurerecup,
    ];

    header("Location: demande.php?succes=ajoute&voiture=" . urlencode($voiture_nom));
    exit();
}

// ─── SUPPRIMER UN ITEM ────────────────────────────────────────────────────────
if ($action === 'supprimer') {
    $id = $_GET['id'] ?? '';
    foreach ($_SESSION['panier'] as $key => $item) {
        if ($item['id'] === $id) {
            unset($_SESSION['panier'][$key]);
            $_SESSION['panier'] = array_values($_SESSION['panier']); // réindexer
            break;
        }
    }
    header("Location: Panier.php?succes=supprime");
    exit();
}

// ─── VIDER LE PANIER ─────────────────────────────────────────────────────────
if ($action === 'vider') {
    $_SESSION['panier'] = [];
    header("Location: Panier.php?succes=vide");
    exit();
}

// Fallback
header("Location: demande.php");
exit();