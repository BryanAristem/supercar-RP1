<?php
session_start();
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset(); session_destroy();
    header("Location: Acceuil.php"); exit();
}

// Connexion BDD pour récupérer les voitures
$pdo = new PDO("mysql:host=localhost;dbname=supercar", "root", "", [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);
$voitures = $pdo->query('SELECT * FROM voiture ORDER BY disponible DESC, id DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Voitures – SuperCar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .dropdown-menu { border-radius:10px; border:none; box-shadow:0 8px 24px rgba(0,0,0,0.12); min-width:180px; padding:8px 0; }
        .dropdown-item { padding:9px 18px; font-size:0.9rem; transition:background 0.15s; }
        .dropdown-item:hover { background:#f0faf6; color:#12906c; }
        .dropdown-item.text-danger:hover { background:#fff0f0; color:#dc3545 !important; }
        .car-wrap { position: relative; }
        .car-wrap.indisponible { opacity: 0.7; }
        .car-wrap.indisponible::before { content:''; position:absolute; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.3); z-index:1; border-radius:4px; }
        .badge-disponibilite { position:absolute; top:15px; right:15px; z-index:2; padding:8px 15px; border-radius:20px; font-weight:600; font-size:0.85rem; text-transform:uppercase; box-shadow:0 2px 8px rgba(0,0,0,0.2); }
        .badge-disponible   { background:#28a745; color:white; }
        .badge-indisponible { background:#dc3545; color:white; }
        .car-wrap.indisponible .btn-primary { background:#6c757d; border-color:#6c757d; cursor:not-allowed; pointer-events:none; }
        .car-wrap.indisponible .text { position:relative; z-index:2; }
    </style>
</head>
<body>

<?php require_once 'navbar_fragment.php'; ?>

<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('images/cardealership.jpg');" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
            <div class="col-md-9 ftco-animate pb-5">
                <p class="breadcrumbs"><span class="mr-2"><a href="Acceuil.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>Voitures <i class="ion-ios-arrow-forward"></i></span></p>
                <h1 class="mb-3 bread">Catalogue de voitures</h1>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section bg-light">
    <div class="container">
        <div class="row">
            <?php foreach ($voitures as $index => $voiture):
                $disponible = (int)$voiture['disponible'];
                $wrapClass  = $disponible ? '' : 'indisponible';
                $badgeClass = $disponible ? 'badge-disponible' : 'badge-indisponible';
                $badgeText  = $disponible ? 'Disponible' : 'Indisponible';
            ?>
            <div class="col-md-4 car-item">
                <div class="car-wrap rounded ftco-animate <?= $wrapClass ?>">
                    <span class="badge-disponibilite <?= $badgeClass ?>">
                        <i class="fas fa-<?= $disponible ? 'check-circle' : 'times-circle' ?>"></i> <?= $badgeText ?>
                    </span>
                    <div class="img rounded d-flex align-items-end"
                         style="background-image: url(<?= htmlspecialchars($voiture['photo'] ?? 'images/default.jpg') ?>);"></div>
                    <div class="text">
                        <h2 class="mb-0"><a href="#"><?= htmlspecialchars($voiture['marque'] . ' ' . $voiture['modele']) ?></a></h2>
                        <div class="d-flex mb-3">
                            <span class="cat"><?= htmlspecialchars($voiture['categorie'] ?? 'Non spécifiée') ?></span>
                            <p class="price ml-auto"><?= number_format($voiture['prix'], 2) ?><span>MUR /jour</span></p>
                        </div>
                        <p class="description"  style="display:none;"><?= htmlspecialchars($voiture['description']  ?? '') ?></p>
                        <p class="transmission" style="display:none;"><?= htmlspecialchars($voiture['transmission'] ?? '') ?></p>
                        <p class="disponibilite-hidden" style="display:none;"><?= $disponible ?></p>
                        <p class="d-flex mb-0">
                            <?php if ($disponible): ?>
                                <a href="demande.php?voiture_id=<?= $voiture['id'] ?>" class="btn btn-primary py-2 mr-1">Essayer</a>
                            <?php else: ?>
                                <button class="btn btn-primary py-2 mr-1" disabled>Essayer</button>
                            <?php endif; ?>
                            <button class="btn btn-secondary py-2 ml-1" data-target="#carDetailsModal<?= $voiture['id'] ?>">Détails</button>
                        </p>
                    </div>
                </div>
            </div>
            <?php if (($index + 1) % 3 == 0): ?></div><div class="row"><?php endif; ?>
            <?php endforeach; ?>
        </div>

        <!-- Modal détails -->
        <div class="modal fade" id="carDetailsModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalCarTitle"></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                    </div>
                    <div class="modal-body text-center">
                        <div id="modalDisponibilite" class="mb-3"></div>
                        <img id="modalCarPhoto" src="" class="img-fluid mb-3" alt="">
                        <p><strong>Catégorie :</strong> <span id="modalCarCategorie"></span></p>
                        <p><strong>Prix :</strong> <span id="modalCarPrix"></span> MUR / jour</p>
                        <p><strong>Description :</strong> <span id="modalCarDescription"></span></p>
                        <p><strong>Transmission :</strong> <span id="modalCarTransmission"></span></p>
                    </div>
                    <div class="modal-footer">
                        <a href="demande.php" class="btn btn-primary" id="modalTestBtn">Tester cette voiture</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<footer style="background: linear-gradient(135deg, #021638cc, #12906c, #021638cc); color: white; padding: 1.5rem 0; text-align: center; font-family: 'Segoe UI', sans-serif; margin-top: 3rem; box-shadow: 0 -5px 15px rgba(0,0,0,0.1);">
    <div style="max-width:1200px; margin:0 auto; padding:0 20px;">
        <p style="margin:0;">&copy; SUPERCAR 2024-2026 | By Student MCCI | SIO</p>
        <div style="margin-top:1rem; display:flex; justify-content:center; gap:1.5rem;">
            <a href="contacts.php" style="color:white; text-decoration:none;"><i class="fas fa-envelope"></i> Contact</a>
            <a href="confidentialité.html" style="color:white; text-decoration:none;"><i class="fas fa-shield-alt"></i> Confidentialité</a>
            <a href="Mention.html" style="color:white; text-decoration:none;"><i class="fas fa-file-alt"></i> Mentions légales</a>
        </div>
    </div>
</footer>

<div id="ftco-loader" class="show fullscreen">
    <svg class="circular" width="48px" height="48px">
        <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/>
        <circle class="path"    cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/>
    </svg>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="js/main.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const modal = new bootstrap.Modal(document.getElementById('carDetailsModal'));
    document.querySelectorAll('button[data-target^="#carDetailsModal"]').forEach(button => {
        button.addEventListener('click', function () {
            const row = this.closest('.col-md-4');
            document.getElementById('modalCarTitle').textContent       = row.querySelector('h2 a').textContent;
            document.getElementById('modalCarPhoto').src               = row.querySelector('.img').style.backgroundImage.slice(5,-2);
            document.getElementById('modalCarPhoto').alt               = row.querySelector('h2 a').textContent;
            document.getElementById('modalCarCategorie').textContent   = row.querySelector('.cat').textContent;
            document.getElementById('modalCarPrix').textContent        = row.querySelector('.price').textContent.split(' ')[0];
            document.getElementById('modalCarDescription').textContent = row.querySelector('p.description')?.textContent  ?? '';
            document.getElementById('modalCarTransmission').textContent= row.querySelector('p.transmission')?.textContent ?? '';
            const disponible = parseInt(row.querySelector('p.disponibilite-hidden')?.textContent ?? '1');
            const dispEl  = document.getElementById('modalDisponibilite');
            const testBtn = document.getElementById('modalTestBtn');
            if (disponible === 1) {
                dispEl.innerHTML = '<span class="badge bg-success" style="font-size:1rem;padding:10px 20px;"><i class="fas fa-check-circle"></i> Disponible</span>';
                testBtn.style.display = 'inline-block';
            } else {
                dispEl.innerHTML = '<span class="badge bg-danger" style="font-size:1rem;padding:10px 20px;"><i class="fas fa-times-circle"></i> Indisponible</span>';
                testBtn.style.display = 'none';
            }
            modal.show();
        });
    });
});
</script>
</body>
</html>
