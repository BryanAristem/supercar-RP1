<?php
session_start();

$host = "localhost"; $login = "root"; $pass = ""; $bdd = "supercar";
$conn = new mysqli($host, $login, $pass, $bdd);
if ($conn->connect_error) die("Erreur de connexion : " . $conn->connect_error);

$error = "";

// Si déjà connecté, rediriger directement
if (isset($_SESSION["user_id"])) {
    header("Location: Acceuil.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = $_POST["email"]    ?? "";
    $password = $_POST["password"] ?? "";

    $sql  = "SELECT id, nom, password FROM inscription WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user["password"])) {
            $_SESSION["user_id"]  = $user["id"];
            $_SESSION["user_nom"] = $user["nom"];
            header("Location: Acceuil.php");
            exit();
        } else {
            $error = "Mot de passe incorrect.";
        }
    } else {
        $error = "Email non trouvé.";
    }
    $stmt->close();
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Connexion – SuperCar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body, html { height: 100%; margin: 0; }
        .video-bg { position: fixed; top: 0; left: 0; min-width: 100%; min-height: 100%; z-index: -1; object-fit: cover; }
        .overlay  { position: fixed; top: 0; left: 0; height: 100%; width: 100%; background: rgba(0,0,0,0.4); z-index: 0; }
        .center-container { min-height: 100vh; display: flex; align-items: center; justify-content: center; position: relative; z-index: 1; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container-fluid px-0">
        <a class="navbar-brand ml-lg-5 ml-3" href="Acceuil.php">Super<span>car</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
            <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a href="Acceuil.php" class="nav-link">Accueil</a></li>
                <li class="nav-item"><a href="car.php" class="nav-link">Voitures</a></li>
                <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
                <li class="nav-item"><a href="demande.php" class="nav-link">Demande d'essai</a></li>
                <li class="nav-item"><a href="contacts.php" class="nav-link">Contactez-nous</a></li>
            </ul>
            <ul class="navbar-nav" style="margin-right: 50px;">
                <li class="nav-item">
                    <a href="inscription.php" class="nav-link"><i class="fas fa-user-plus"></i> S'inscrire</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Fond vidéo -->
<video autoplay muted loop class="video-bg">
    <source src="video/Car Turning On Hazard .mp4" type="video/mp4">
</video>
<div class="overlay"></div>

<!-- Formulaire -->
<div class="center-container">
    <div class="col-lg-4 bg-white p-4 rounded shadow">
        <h2 class="text-center">Connexion</h2>
        <p class="text-center text-muted lead">Se connecter à SuperCar</p>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form action="connexion.php" method="POST">
            <div class="input-group mb-3">
                <span class="input-group-text"><i class="fa fa-envelope"></i></span>
                <input type="email" name="email" class="form-control" placeholder="Votre E-mail" required>
            </div>
            <div class="input-group mb-4">
                <span class="input-group-text"><i class="fa fa-lock"></i></span>
                <input type="password" name="password" id="password" class="form-control" placeholder="Votre mot de passe" required>
                <span class="input-group-text" id="togglePassword" style="cursor:pointer;">
                    <i class="fa fa-eye"></i>
                </span>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-success w-100 py-2">Se connecter</button>
            </div>
        </form>

        <p class="text-center mt-3">
            Pas encore de compte ? <a href="inscription.php">S'inscrire</a>
        </p>
    </div>
</div>

<!-- Footer -->
<footer style="background: linear-gradient(135deg, #021638cc, #12906c, #021638cc); color: white; padding: 1.5rem 0; text-align: center; position: relative; margin-top: 3rem;">
    <p style="margin:0;">&copy; SUPERCAR 2024-2026 | By Student MCCI | SIO</p>
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
document.getElementById('togglePassword').addEventListener('click', function () {
    const pwd = document.getElementById('password');
    const eye = this.querySelector('i');
    if (pwd.type === 'password') {
        pwd.type = 'text';
        eye.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        pwd.type = 'password';
        eye.classList.replace('fa-eye-slash', 'fa-eye');
    }
});
</script>
</body>
</html>
