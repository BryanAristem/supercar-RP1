<?php
session_start();
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset(); session_destroy();
    header("Location: Acceuil.php"); exit();
}

// ── Traitement du formulaire (anciennement contact.php) ──
$contact_succes = false;
$contact_erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_SESSION['message_envoye'])) {
        $contact_erreur = "Vous avez déjà envoyé un message.";
    } else {
        $conn = new mysqli("localhost", "root", "", "supercar");
        if ($conn->connect_error) {
            $contact_erreur = "Échec de la connexion : " . $conn->connect_error;
        } else {
            $nom     = htmlspecialchars($_POST['nom']     ?? '');
            $email   = htmlspecialchars($_POST['email']   ?? '');
            $sujet   = htmlspecialchars($_POST['sujet']   ?? '');
            $message = htmlspecialchars($_POST['message'] ?? '');

            if (!$nom || !$email) {
                $contact_erreur = "Veuillez remplir tous les champs requis.";
            } else {
                $sql = "INSERT INTO contactez (nom, email, sujet, message)
                        VALUES ('$nom', '$email', '$sujet', '$message')";
                if ($conn->query($sql) === TRUE) {
                    $_SESSION['message_envoye'] = true;
                    $contact_succes = true;
                } else {
                    $contact_erreur = "Erreur BDD : " . $conn->error;
                }
            }
            $conn->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact – SuperCar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .dropdown-menu { border-radius:10px; border:none; box-shadow:0 8px 24px rgba(0,0,0,0.12); min-width:180px; padding:8px 0; }
        .dropdown-item { padding:9px 18px; font-size:0.9rem; transition:background 0.15s; }
        .dropdown-item:hover { background:#f0faf6; color:#12906c; }
        .dropdown-item.text-danger:hover { background:#fff0f0; color:#dc3545 !important; }
    </style>
</head>
<body>

<?php require_once 'navbar_fragment.php'; ?>

<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('images/Cont.jpeg');" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
            <div class="col-md-9 ftco-animate pb-5">
                <p class="breadcrumbs"><span class="mr-2"><a href="Acceuil.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>Contact <i class="ion-ios-arrow-forward active"></i></span></p>
                <h1 class="mb-3 bread">Contactez-nous</h1>
            </div>
        </div>
    </div>
</section>

<section class="Contact-section">
    <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row gy-4">

            <!-- Infos de contact -->
            <div class="col-lg-4">
                <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="300">
                    <i class="bi bi-geo-alt flex-shrink-0"></i>
                    <div><h3>Adresse</h3><p>Ebène, Maurice</p></div>
                </div>
                <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
                    <i class="bi bi-telephone flex-shrink-0"></i>
                    <div><h3>Appelez-nous</h3><p><a href="tel:+23070110033">Jean Dubois (+230 70110033)</a></p></div>
                </div>
                <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="500">
                    <i class="bi bi-envelope flex-shrink-0"></i>
                    <div><h3>Email</h3><p><a href="mailto:infoSuperCar@gmail.com">infoSuperCar@gmail.com</a></p></div>
                </div>
            </div>

            <!-- Formulaire de contact -->
            <div class="col-lg-8">

                <?php if (!empty($contact_erreur)): ?>
                    <div class="alert alert-warning mb-3"><?= htmlspecialchars($contact_erreur) ?></div>
                <?php endif; ?>

                <?php if ($contact_succes): ?>
                    <!-- Message de succès -->
                    <div style="color:green; text-align:center; margin-top:120px; font-size:45px;">
                        <i class="fas fa-check-circle"></i> Message envoyé avec succès !
                    </div>
                <?php else: ?>
                    <!-- Formulaire : envoie vers cette même page -->
                    <form id="contactForm" action="contacts.php" method="POST" class="bg-light p-5 contact-form">
                        <div class="form-group">
                            <input type="text" class="form-control" name="nom" placeholder="Nom" required>
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="sujet" placeholder="Sujet">
                        </div>
                        <div class="form-group">
                            <textarea name="message" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Envoyer" class="btn btn-primary py-3 px-5">
                        </div>
                    </form>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>

<div class="col-md-12 text-center">
    <div class="mb-4" data-aos="fade-up" data-aos-delay="200">
        <h4>Localisation</h4>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3743.3006031008176!2d57.4867236750091!3d-20.246364181214368!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x217c5b1ef2170f63%3A0xd1a78020fc096491!2sMCCI%20BUSINESS%20SCHOOL!5e0!3m2!1sfr!2smu!4v1733312722116!5m2!1sfr!2smu"
                width="90%" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</div>

<footer style="background: linear-gradient(135deg, #021638cc, #12906c, #021638cc); color: white; padding: 1.5rem 0; text-align: center; font-family: 'Segoe UI', sans-serif; margin-top: 3rem; box-shadow: 0 -5px 15px rgba(0,0,0,0.1);">
    <div style="max-width:1200px; margin:0 auto; padding:0 20px;">
        <p style="margin:0;">&copy; SUPERCAR 2024-2026 | By Student MCCI | SIO</p>
        <div style="margin-top:1rem; display:flex; justify-content:center; gap:1.5rem;">
            <a href="contacts.php" style="color:white; text-decoration:none;"><i class="fas fa-envelope"></i> Contact</a>
            <a href="confidentialité.html" style="color:white; text-decoration:none;"><i class="fas fa-shield-alt"></i> Confidentialité</a>
            <a href="Mention.html" style="color:white; text-decoration:none;"><i class="fas fa-file-alt"></i> Mentions légales</a>
        </div>
    </div>
</footer>

<div id="ftco-loader" class="show fullscreen">
    <svg class="circular" width="48px" height="48px">
        <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/>
        <circle class="path"    cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/>
    </svg>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>
