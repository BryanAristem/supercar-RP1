<?php
session_start();

// Protection : doit être connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php");
    exit();
}

$user_nom = $_SESSION['user_nom'] ?? 'Utilisateur';

// Panier en session
if (!isset($_SESSION['panier'])) $_SESSION['panier'] = [];
$nb_panier = count($_SESSION['panier']);

// Connexion BDD
$pdo = new PDO("mysql:host=localhost;dbname=supercar", "root", "", [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

// Récupérer nom/prénom/email de l'utilisateur connecté pour pré-remplir
$user_info = ['nom' => '', 'prenom' => '', 'email' => ''];
$stmt_user = $pdo->prepare("SELECT nom, prenom, email FROM inscription WHERE id = ?");
$stmt_user->execute([$_SESSION['user_id']]);
$row = $stmt_user->fetch();
if ($row) $user_info = $row;

// Voitures disponibles
$voitures = $pdo->query("SELECT id, marque, modele FROM voiture")->fetchAll();

// Voiture pré-sélectionnée depuis car.php
$voiture_preselect_id  = $_GET['voiture_id'] ?? null;
$voiture_preselect_nom = '';
if ($voiture_preselect_id) {
    $stmt = $pdo->prepare("SELECT marque, modele FROM voiture WHERE id = ?");
    $stmt->execute([$voiture_preselect_id]);
    $v = $stmt->fetch();
    if ($v) $voiture_preselect_nom = $v['marque'] . ' ' . $v['modele'];
}

// Messages de notification
$message = ''; $message_type = '';
if (isset($_GET['succes'])) {
    if ($_GET['succes'] === 'ajoute') {
        $message = "✅ <strong>" . htmlspecialchars(urldecode($_GET['voiture'] ?? '')) . "</strong> ajoutée au panier ! ($nb_panier/3)";
        $message_type = 'success';
    } elseif ($_GET['succes'] === 'direct') {
        $message = "✅ Votre essai pour <strong>" . htmlspecialchars(urldecode($_GET['voiture'] ?? '')) . "</strong> a été enregistré !";
        $message_type = 'success';
    }
}
if (isset($_GET['erreur'])) {
    switch ($_GET['erreur']) {
        case 'panier_plein':
            $message = "⚠️ Votre panier est plein (3 demandes maximum)."; $message_type = 'warning'; break;
        case 'doublon':
            $message = "⚠️ Cette voiture est déjà dans votre panier."; $message_type = 'warning'; break;
        case 'champs_manquants':
            $message = "❌ Veuillez remplir tous les champs obligatoires."; $message_type = 'danger'; break;
    }
}

$voitures_panier = array_column($_SESSION['panier'], 'voiture_id');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Demande d'essai – SuperCar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .dropdown-menu { border-radius:10px; border:none; box-shadow:0 8px 24px rgba(0,0,0,0.12); min-width:180px; padding:8px 0; }
        .dropdown-item { padding:9px 18px; font-size:0.9rem; transition:background 0.15s; }
        .dropdown-item:hover { background:#f0faf6; color:#12906c; }
        .dropdown-item.text-danger:hover { background:#fff0f0; color:#dc3545 !important; }

        .panier-nav-link { position:relative; display:inline-flex; align-items:center; color:rgba(255,255,255,0.7); text-decoration:none; padding:0.5rem 0.75rem; transition:color 0.2s; }
        .panier-nav-link:hover { color:#fff; text-decoration:none; }
        .panier-nav-link i { font-size:1.3rem; }
        .panier-badge { position:absolute; top:2px; right:4px; background:#0dfdd5; color:#111; border-radius:50%; font-size:0.65rem; font-weight:700; width:18px; height:18px; display:flex; align-items:center; justify-content:center; }
        .panier-badge.hidden { display:none; }

        .toast-notification { position:fixed; top:90px; right:20px; z-index:9999; max-width:380px; border-radius:10px; padding:14px 20px; font-size:0.95rem; box-shadow:0 6px 20px rgba(0,0,0,0.15); }
        .alert-success-toast { background:#d4edda; color:#155724; border-left:4px solid #28a745; }
        .alert-warning-toast { background:#fff3cd; color:#856404; border-left:4px solid #ffc107; }
        .alert-danger-toast  { background:#f8d7da; color:#721c24; border-left:4px solid #dc3545; }

        .label { font-size:.85rem; font-weight:600; color:#555; margin-bottom:5px; display:block; }
        .auto-filled { background:#f0fff8; border-color:#28a745; }
        .prefilled-badge { background:#28a745; color:white; font-size:.7rem; padding:2px 8px; border-radius:20px; margin-bottom:5px; display:inline-block; }

        .btn-panier { width:100%; background:linear-gradient(135deg,#6f42c1,#8a5fd4); color:white; border:none; border-radius:8px; padding:12px; font-weight:600; cursor:pointer; transition:all .3s; margin-bottom:10px; }
        .btn-panier:hover { background:linear-gradient(135deg,#5a359d,#7549b8); transform:translateY(-1px); }
        .btn-panier:disabled { background:#ccc; cursor:not-allowed; transform:none; }

        .ou-separator { display:flex; align-items:center; gap:12px; margin:16px 0; color:#999; font-size:.85rem; }
        .ou-separator hr { flex:1; border-color:#ddd; }

        .btn-enregistrer-now { width:100%; background:linear-gradient(135deg,#12906c,#17b588); color:white; border:none; border-radius:8px; padding:12px; font-weight:600; cursor:pointer; transition:all .3s; margin-bottom:5px; }
        .btn-enregistrer-now:hover { background:linear-gradient(135deg,#0e7358,#14a07a); transform:translateY(-1px); }
        .btn-enregistrer-now-hint { text-align:center; font-size:.75rem; color:#999; margin-bottom:12px; }

        .btn-voir-panier { display:block; text-align:center; background:#fff3cd; color:#856404; border:1px solid #ffc107; border-radius:8px; padding:10px; text-decoration:none; font-weight:600; font-size:.9rem; transition:all .3s; }
        .btn-voir-panier:hover { background:#ffe69c; text-decoration:none; }

        .voiture-selected-display { display:none; background:#f8f9fa; border:1px solid #dee2e6; border-radius:8px; padding:10px 14px; margin-bottom:10px; }
        .voiture-selected-display span { font-weight:600; }
    </style>
</head>
<body>

<?php require_once 'navbar_fragment.php'; ?>

<!-- Panier icon dans la navbar (ajouté juste après navbar_fragment si besoin, ici dans la page) -->

<?php if (!empty($message)): ?>
<div class="toast-notification alert-<?= $message_type ?>-toast">
    <?= $message ?>
</div>
<script>setTimeout(() => document.querySelector('.toast-notification').remove(), 4000);</script>
<?php endif; ?>

<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('images/cardealership.jpg');" data-stellar-background-ratio="0.5">">
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
            <div class="col-md-9 ftco-animate pb-5">
                <p class="breadcrumbs"><span class="mr-2"><a href="Acceuil.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>Demande d'essai <i class="ion-ios-arrow-forward"></i></span></p>
                <h1 class="mb-3 bread">Demande d'essai</h1>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section">
    <div class="container">
        <div class="row">
            <!-- Formulaire -->
            <div class="col-md-4 order-md-last ftco-animate">
                <form id="essai-form" action="Panier_action.php" method="POST">
                    <input type="hidden" name="action" id="form-action" value="ajouter">
                    <input type="hidden" name="voiture_nom" id="voiture_nom" value="<?= htmlspecialchars($voiture_preselect_nom) ?>">

                    <!-- Sélection voiture -->
                    <div class="form-group">
                        <label class="label">Voiture</label>
                        <select class="form-control" name="voiture_id" id="voiture_id" required onchange="updateVoitureDisplay(this)">
                            <option value="">-- Choisir une voiture --</option>
                            <?php foreach ($voitures as $v): ?>
                                <option value="<?= $v['id'] ?>"
                                    <?= ($v['id'] == $voiture_preselect_id) ? 'selected' : '' ?>
                                    data-panier="<?= in_array($v['id'], $voitures_panier) ? '1' : '0' ?>">
                                    <?= htmlspecialchars($v['marque'] . ' ' . $v['modele']) ?>
                                    <?= in_array($v['id'], $voitures_panier) ? ' (déjà dans le panier)' : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Affichage voiture sélectionnée -->
                    <div class="voiture-selected-display" id="voiture-selected-display">
                        <span id="voiture-selected-text"></span>
                        <span id="voiture-panier-tag" style="display:none; color:#ffc107; font-size:.75rem; margin-left:8px;">⚠ Dans le panier</span>
                    </div>

                    <!-- Nom -->
                    <div class="form-group">
                        <label class="label">Nom</label>
                        <?php if ($user_info['nom']): ?>
                            <span class="prefilled-badge"><i class="fas fa-check mr-1"></i>Auto-rempli</span>
                        <?php endif; ?>
                        <input type="text" class="form-control <?= $user_info['nom'] ? 'auto-filled' : '' ?>"
                               name="nom" placeholder="Votre nom" required value="<?= htmlspecialchars($user_info['nom']) ?>">
                    </div>

                    <!-- Prénom -->
                    <div class="form-group">
                        <label class="label">Prénom</label>
                        <input type="text" class="form-control <?= $user_info['prenom'] ? 'auto-filled' : '' ?>"
                               name="prenom" placeholder="Votre prénom" required value="<?= htmlspecialchars($user_info['prenom']) ?>">
                    </div>

                    <!-- Email -->
                    <div class="form-group">
                        <label class="label">Email</label>
                        <?php if ($user_info['email']): ?>
                            <span class="prefilled-badge"><i class="fas fa-check mr-1"></i>Auto-rempli</span>
                        <?php endif; ?>
                        <input type="email" class="form-control <?= $user_info['email'] ? 'auto-filled' : '' ?>"
                               name="email" placeholder="Votre email" required value="<?= htmlspecialchars($user_info['email']) ?>">
                    </div>

                    <!-- Lieux -->
                    <div class="form-group">
                        <label class="label">Lieu de récupération</label>
                        <input type="text" class="form-control" name="lieurecup" placeholder="Ville, Quartier">
                    </div>
                    <div class="form-group">
                        <label class="label">Lieu de dépôt</label>
                        <input type="text" class="form-control" name="lieudepot" placeholder="Ville, Quartier">
                    </div>

                    <!-- Dates -->
                    <label class="label">Dates</label>
                    <div class="d-flex">
                        <div class="form-group mr-2">
                            <label class="label">Récupération</label>
                            <input type="date" class="form-control" name="daterecup" required>
                        </div>
                        <div class="form-group ml-2">
                            <label class="label">Dépôt</label>
                            <input type="date" class="form-control" name="datedepot" required>
                        </div>
                    </div>

                    <!-- Heure -->
                    <div class="form-group">
                        <label class="label">Heure de récupération</label>
                        <input type="time" class="form-control" name="heurerecup" id="heurerecup" required>
                    </div>

                    <!-- Ajouter au panier -->
                    <?php if ($nb_panier < 3): ?>
                        <button type="submit" class="btn-panier" onclick="setActionPanier()">
                            <i class="fas fa-cart-plus"></i> Ajouter au panier
                        </button>
                    <?php else: ?>
                        <button type="button" class="btn-panier" disabled>
                            <i class="fas fa-ban"></i> Panier plein (3/3)
                        </button>
                    <?php endif; ?>

                    <div class="ou-separator"><hr><span>ou</span><hr></div>

                    <!-- Enregistrer directement (bypass panier → BDD via Confirmation_demander) -->
                    <button type="submit" class="btn-enregistrer-now" onclick="setActionDirect()">
                        Enregistrer
                    </button>
                    <p class="btn-enregistrer-now-hint">sélection pour un seul essai</p>

                    <?php if ($nb_panier > 0): ?>
                        <a href="panier.php" class="btn-voir-panier">
                            <i class="fas fa-shopping-cart"></i>
                            Voir mon panier (<?= $nb_panier ?> demande<?= $nb_panier > 1 ? 's' : '' ?>)
                        </a>
                    <?php endif; ?>
                </form>
            </div>

            <!-- Explication -->
            <div class="col-md-8 d-flex align-items-center">
                <div class="services-wrap rounded-right w-100">
                    <h3 class="heading-section mb-4">Comment faire une demande d'essai ?</h3>
                    <div class="row d-flex mb-4">
                        <div class="col-md-4 d-flex align-self-stretch ftco-animate">
                            <div class="services w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="flaticon-route"></span>
                                </div>
                                <div class="text w-100">
                                    <h3 class="heading mb-2">Choisir le lieu et l'heure de récupération</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex align-self-stretch ftco-animate">
                            <div class="services w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="flaticon-rent"></span>
                                </div>
                                <div class="text w-100">
                                    <h3 class="heading mb-2">Choisissez le modèle que vous voulez</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex align-self-stretch ftco-animate">
                            <div class="services w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="flaticon-rent"></span>
                                </div>
                                <div class="text w-100">
                                    <h3 class="heading mb-2">Validez votre panier (3 essais max)</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<footer style="background: linear-gradient(135deg, #247eec, #12906c, #2d73ed); color: white; padding: 1.5rem 0; text-align: center; font-family: 'Segoe UI', sans-serif; margin-top: 3rem; box-shadow: 0 -5px 15px rgba(0,0,0,0.1);">
    <div style="max-width:1200px; margin:0 auto; padding:0 20px;">
        <p style="margin:0;">&copy; SUPERCAR 2024-2026 | By Student MCCI | SIO</p>
        <div style="margin-top:1rem; display:flex; justify-content:center; gap:1.5rem;">
            <a href="contacts.php" style="color:white; text-decoration:none;"><i class="fas fa-envelope"></i> Contact</a>
            <a href="confidentialité.html" style="color:white; text-decoration:none;"><i class="fas fa-shield-alt"></i> Confidentialité</a>
            <a href="Mention.html" style="color:white; text-decoration:none;"><i class="fas fa-file-alt"></i> Mentions légales</a>
        </div>
    </div>
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="js/main.js"></script>
<script>
function setActionPanier() {
    var form = document.getElementById('essai-form');
    form.action = 'Panier_action.php';
    document.getElementById('form-action').value = 'ajouter';
}
function setActionDirect() {
    var form = document.getElementById('essai-form');
    form.action = 'Confirmation_demander.php';
    document.getElementById('form-action').value = 'direct';
}
function updateVoitureDisplay(select) {
    var display  = document.getElementById('voiture-selected-display');
    var textEl   = document.getElementById('voiture-selected-text');
    var tagEl    = document.getElementById('voiture-panier-tag');
    var nomInput = document.getElementById('voiture_nom');
    if (select.value) {
        var opt      = select.options[select.selectedIndex];
        var nom      = opt.text.replace(' (déjà dans le panier)', '').trim();
        var inPanier = opt.getAttribute('data-panier') === '1';
        nomInput.value      = nom;
        textEl.textContent  = nom;
        tagEl.style.display = inPanier ? 'inline' : 'none';
        display.style.display = 'none';
        void display.offsetWidth;
        display.style.display = 'block';
    } else {
        nomInput.value        = '';
        display.style.display = 'none';
    }
}
window.addEventListener('load', function () {
    var sel = document.getElementById('voiture_id');
    if (sel.value) updateVoitureDisplay(sel);
});
</script>
</body>
</html>
