<?php
session_start();

// Si déjà connecté, rediriger
if (isset($_SESSION["user_id"])) {
    header("Location: Acceuil.php");
    exit();
}

$host = 'localhost'; $db = 'supercar'; $user = 'root'; $pass = '';
$dsn  = "mysql:host=$host;dbname=$db;charset=utf8";
try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (\PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

$erreur = '';

if (isset($_POST['valider'])) {
    $nom      = trim($_POST['nom']      ?? '');
    $prenom   = trim($_POST['prenom']   ?? '');
    $email    = trim($_POST['email']    ?? '');
    $mdp      = $_POST['password']      ?? '';

    if (!$nom || !$prenom || !$email || !$mdp) {
        $erreur = "Veuillez remplir tous les champs.";
    } elseif (strlen($mdp) < 6) {
        $erreur = "Le mot de passe doit faire au moins 6 caractères.";
    } else {
        // Vérifier si l'email existe déjà
        $check = $pdo->prepare("SELECT id FROM inscription WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) {
            $erreur = "Cette adresse e-mail est déjà utilisée.";
        } else {
            $hash = password_hash($mdp, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO inscription (nom, prenom, email, password, date_inscription) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$nom, $prenom, $email, $hash]);

            // Connexion automatique après inscription
            $_SESSION['user_id']  = $pdo->lastInsertId();
            $_SESSION['user_nom'] = $nom;
            header("Location: Acceuil.php");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription – SuperCar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        html, body { margin: 0; padding: 0; font-family: 'Poppins', sans-serif; background-image: url("images/perfect.jpg"); background-size: cover; background-position: center; background-attachment: fixed; min-height: 100vh; }
        .containe { display: flex; align-items: center; justify-content: center; min-height: calc(100vh - 80px - 80px); padding: 30px 15px; }
        .form-box { background-color: rgba(255,255,255,0.96); box-shadow: 0 8px 25px rgba(0,0,0,0.2); padding: 30px; border-radius: 10px; width: 100%; max-width: 420px; }
        .alert-custom { background: #f8d7da; color: #721c24; border-left: 4px solid #dc3545; border-radius: 8px; padding: 10px 14px; font-size: 0.88rem; margin-bottom: 1rem; }
        footer { background: linear-gradient(135deg, #021638cc, #12906c, #021638cc); color: white; padding: 1rem 0; text-align: center; }
        footer a { color: white; text-decoration: none; margin: 0 10px; }
        /* Afficher/masquer mot de passe */
        .input-group { position: relative; }
        .input-group .form-control { padding-right: 40px; }
        .toggle-pwd { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; z-index: 10; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container-fluid px-0">
        <a class="navbar-brand ml-lg-5 ml-3" href="Acceuil.php">Super<span>car</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
            <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a href="Acceuil.php" class="nav-link">Accueil</a></li>
                <li class="nav-item"><a href="car.php" class="nav-link">Voitures</a></li>
                <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
                <li class="nav-item"><a href="demande.php" class="nav-link">Demande d'essai</a></li>
                <li class="nav-item"><a href="contacts.php" class="nav-link">Contactez-nous</a></li>
            </ul>
            <ul class="navbar-nav" style="margin-right: 50px;">
                <li class="nav-item">
                    <a href="connexion.php" class="nav-link"><i class="fas fa-sign-in-alt"></i> Se connecter</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Formulaire -->
<div class="containe">
    <div class="form-box">
        <h2 class="text-center">Inscription</h2>
        <p class="text-center text-muted">Créez votre compte SuperCar</p>

        <?php if ($erreur): ?>
            <div class="alert-custom"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($erreur) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <input type="text" name="nom" class="form-control" placeholder="Votre Nom"
                       value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <input type="text" name="prenom" class="form-control" placeholder="Votre Prénom"
                       value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <input type="email" name="email" class="form-control" placeholder="Votre E-mail"
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </div>
            <div class="mb-4 input-group">
                <input type="password" name="password" id="password" class="form-control"
                       placeholder="Créez un mot de passe (6 caractères min.)" required>
                <button type="button" class="toggle-pwd" id="togglePassword">
                    <i class="fa fa-eye"></i>
                </button>
            </div>
            <button type="submit" name="valider" class="btn btn-success w-100">S'inscrire</button>
        </form>

        <p class="text-center mt-3">
            Déjà un compte ? <a href="connexion.php">Se connecter</a>
        </p>
    </div>
</div>

<!-- Footer -->
<footer>
    <p>&copy; SUPERCAR 2024-2026 | By Student MCCI | SIO</p>
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
document.getElementById('togglePassword').addEventListener('click', function () {
    const pwd = document.getElementById('password');
    const eye = this.querySelector('i');
    if (pwd.type === 'password') {
        pwd.type = 'text';
        eye.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        pwd.type = 'password';
        eye.classList.replace('fa-eye-slash', 'fa-eye');
    }
});
</script>
</body>
</html>
