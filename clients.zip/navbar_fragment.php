<?php
/**
 * navbar_fragment.php
 * -------------------
 * À inclure dans chaque page après session_start().
 * Affiche : nom de l'utilisateur + dropdown (Déconnexion) si connecté,
 *           sinon bouton "Se connecter".
 *
 * Usage dans une page :
 *   <?php session_start(); require_once 'navbar_fragment.php'; ?>
 *
 * Remplacez <li class="nav-item active"> sur le bon lien selon la page.
 */
?>
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container-fluid px-0">
        <a class="navbar-brand ml-lg-5 ml-3" href="Acceuil.php" style="margin-right: -50px;">Super<span>car</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
            <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav mx-auto" style="max-width: 600px; width: 100%; display: flex; flex-wrap: nowrap;">
                <li class="nav-item"><a href="Acceuil.php"  class="nav-link">Accueil</a></li>
                <li class="nav-item"><a href="car.php"      class="nav-link">Voitures</a></li>
                <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
                <li class="nav-item"><a href="demande.php"  class="nav-link" style="white-space:nowrap;">Demande d'essai</a></li>
                <li class="nav-item"><a href="contacts.php" class="nav-link" style="white-space:nowrap;">Contactez-nous</a></li>
            </ul>

            <!-- Droite : connecté ou non -->
            <ul class="navbar-nav align-items-center" style="margin-right: 50px;">
                <?php if (isset($_SESSION['user_id'])): ?>

                    <!-- Icône Panier -->
                    <?php $nb_panier_nav = isset($_SESSION['panier']) ? count($_SESSION['panier']) : 0; ?>
                    <li class="nav-item mr-2">
                        <a href="panier.php" class="nav-link d-flex align-items-center justify-content-center"
                           title="Mon panier"
                           style="position: relative; padding: 0.5rem 0.6rem;">
                            <i class="fas fa-shopping-cart" style="font-size: 1.2rem; color: rgba(255,255,255,0.8);"></i>
                            <?php if ($nb_panier_nav > 0): ?>
                                <span style="
                                    position: absolute;
                                    top: 2px;
                                    right: 2px;
                                    background: #0dfdd5;
                                    color: #111;
                                    border-radius: 50%;
                                    font-size: 0.6rem;
                                    font-weight: 700;
                                    width: 17px;
                                    height: 17px;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    line-height: 1;
                                "><?= $nb_panier_nav ?></span>
                            <?php endif; ?>
                        </a>
                    </li>

                    <!-- Dropdown utilisateur -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#"
                           id="userDropdown" role="button" data-toggle="dropdown"
                           aria-haspopup="true" aria-expanded="false" style="gap: 8px;">
                            <?php $nom_nav = htmlspecialchars($_SESSION['user_nom'] ?? 'Utilisateur'); ?>
                            <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['user_nom'] ?? 'U') ?>&background=12906c&color=fff&size=40"
                                 style="width:34px; height:34px; border-radius:50%; object-fit:cover; border:2px solid #12906c;">
                            <span><?= $nom_nav ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown"
                             style="border-radius:10px; border:none; box-shadow:0 8px 24px rgba(0,0,0,0.12); min-width:180px; padding:8px 0;">
                            <a class="dropdown-item" href="panier.php">
                                <i class="fas fa-shopping-cart mr-2"></i> Mon panier
                                <?php if ($nb_panier_nav > 0): ?>
                                    <span style="background:#0dfdd5; color:#111; border-radius:20px; font-size:.7rem; font-weight:700; padding:1px 7px; margin-left:4px;"><?= $nb_panier_nav ?></span>
                                <?php endif; ?>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt mr-2"></i> Déconnexion
                            </a>
                        </div>
                    </li>

                <?php else: ?>
                    <li class="nav-item">
                        <a href="connexion.php" class="nav-link">
                            <i class="fas fa-sign-in-alt"></i> Se connecter
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>